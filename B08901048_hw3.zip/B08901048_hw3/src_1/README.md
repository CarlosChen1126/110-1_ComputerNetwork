# LSR.py part 1 of hw3

## Run
```python=
cd src_1
python3 LSR.py 
```

## User Command
```shell=
lf <inputfile> (load input file)
of (produce outputfile)
```

- outputfile's name = inputfile_out1.txt and it's in the same directory of inputfile