## LSR_Remove.py part 2 of hw3

## Run
```python=
cd src_2
python3 LSR_Remove.py
```
## User Command
```shell=
lf <inputfile> (load input file)
rm r2 (remove router r2)
of (produce outputfile)
```

- outputfile's name = inputfile_out1.txt and it's in the same directory of inputfile
